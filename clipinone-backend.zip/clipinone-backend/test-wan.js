/**
 * Wan AI 视频生成 —— 独立测试脚本
 *
 * 跟 test-run.js（测 Ken Burns 拼接方案）是两回事，这个测的是真正调用
 * AI 生成模型的路径。跑这个脚本前必须：
 *   1. 在 .env 里配置好 WAN_API_KEY（从 AIMLAPI 或其他聚合平台获取）
 *   2. 在 .env 里配置好 PUBLIC_BASE_URL（你服务器的公网 HTTPS 地址，
 *      比如 https://159-223-175-193.sslip.io）
 *   3. 服务必须已经在跑（node src/server.js 或 pm2），因为这个脚本会把
 *      测试图片复制到 source-images/ 目录，需要服务把它公开访问到
 *
 * 用法：node test-wan.js
 *
 * ⚠️ 这一步会真实调用 AI 视频生成 API，产生真实费用（大概几毛到一两美元
 * 一条，具体看你用的模型档位），不是免费测试，运行前心里有数。
 */

require("dotenv").config();

const fs = require("fs");
const path = require("path");
const { getStyle } = require("./src/styles");
const { buildAIVideo } = require("./src/aiVideoBuilder");

const PUBLIC_BASE_URL = process.env.PUBLIC_BASE_URL;
const SOURCE_IMG_DIR = path.join(__dirname, "source-images");

async function main() {
  if (!process.env.WAN_API_KEY) {
    console.error("❌ 未配置 WAN_API_KEY，先在 .env 里设置");
    process.exit(1);
  }
  if (!PUBLIC_BASE_URL) {
    console.error("❌ 未配置 PUBLIC_BASE_URL，先在 .env 里设置");
    process.exit(1);
  }

  if (!fs.existsSync(SOURCE_IMG_DIR)) {
    fs.mkdirSync(SOURCE_IMG_DIR, { recursive: true });
  }

  // 把测试图片复制到公开目录，模拟真实上传流程
  const testImage = path.join(__dirname, "test-assets", "img1.jpg");
  const publicFileName = `test-wan-${Date.now()}.jpg`;
  const publicPath = path.join(SOURCE_IMG_DIR, publicFileName);
  fs.copyFileSync(testImage, publicPath);
  const publicImageUrl = `${PUBLIC_BASE_URL}/source-images/${publicFileName}`;

  console.log(`测试图片已公开访问：${publicImageUrl}`);
  console.log("开始调用 Wan API 生成视频（预计需要 1-3 分钟）...");

  const style = getStyle("viral");
  const outputPath = path.join(__dirname, "output", "test_wan_ai.mp4");
  const workDir = path.join(__dirname, "tmp", "test_wan_ai");

  const start = Date.now();

  try {
    const result = await buildAIVideo({
      publicImageUrl,
      dish: "红烧肉",
      tagline: "老字号8年",
      style,
      caption: "老字号8年 · 红烧肉必点",
      outputPath,
      workDir,
    });

    const elapsed = ((Date.now() - start) / 1000).toFixed(1);
    console.log(`✅ 生成完成，耗时 ${elapsed}s`);
    console.log(`运镜提示词：${result.motionPrompt}`);
    if (result.creditsUsed) console.log(`消耗 credits：${result.creditsUsed}`);
    console.log(`输出文件：${outputPath}`);
  } finally {
    fs.unlink(publicPath, () => {});
  }
}

main().catch((err) => {
  console.error("❌ 测试失败：", err.message);
  process.exit(1);
});
