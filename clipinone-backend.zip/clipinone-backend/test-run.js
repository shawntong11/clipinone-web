const path = require("path");
const { getStyle } = require("./src/styles");
const { buildVideo } = require("./src/videoBuilder");

const IMAGES = [
  path.join(__dirname, "test-assets", "img1.jpg"),
  path.join(__dirname, "test-assets", "img2.jpg"),
  path.join(__dirname, "test-assets", "img3.jpg"),
  path.join(__dirname, "test-assets", "img4.jpg"),
];

async function main() {
  const styleId = process.argv[2] || "viral";
  const style = getStyle(styleId);

  console.log(`测试风格：${style.name}`);

  const outputPath = path.join(__dirname, "output", `test_${styleId}.mp4`);
  const workDir = path.join(__dirname, "tmp", `test_${styleId}`);

  const start = Date.now();

  await buildVideo({
    imagePaths: IMAGES,
    style,
    caption: "开业8年 · 老字号红烧肉",
    outputPath,
    workDir,
  });

  const elapsed = ((Date.now() - start) / 1000).toFixed(1);
  console.log(`✅ 生成完成，耗时 ${elapsed}s`);
  console.log(`输出文件：${outputPath}`);
}

main().catch((err) => {
  console.error("❌ 测试失败：", err.message);
  process.exit(1);
});
