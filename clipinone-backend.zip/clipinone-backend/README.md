# ClipInOne 后端

图片 + 文案 + 风格 → 10 秒竖屏短视频（9:16，带字幕、配乐）。

已在沙盒环境端到端测试通过：4 个风格全部生成成功，输出规格精确 10.000s /
1080x1920 / h264+aac，字幕位置、颜色、方框按风格配置正确渲染，音频音量正常。

## 目录结构

```
src/
  server.js       Express 服务入口，/api/generate 等接口
  styles.js       风格配置表（4个预设风格的参数，加新风格改这里）
  caption.js      字幕文案生成（调用 Claude API，无 key 时降级为模板）
  videoBuilder.js 核心 FFmpeg 流水线：Ken Burns → 拼接 → 字幕 → 配乐
  music.js        背景音乐（见下方"已知限制"）
test-run.js       直接调用流水线的测试脚本，不经过 HTTP
test-assets/      测试用占位图片
uploads/          用户上传图片的临时存放目录（生成完成后自动清理）
tmp/              每次生成任务的工作目录（生成完成后自动清理）
output/           最终生成的视频文件（长期保留，需要自行做定期清理）
music/            背景音乐文件目录
```

## 快速开始

```bash
npm install
cp .env.example .env   # 按需填入 ANTHROPIC_API_KEY
npm test                # 跑一次端到端测试，生成 output/test_viral.mp4
npm start                # 启动服务，默认监听 3001 端口
```

## 两条视频生成路径

### 路径一：`/api/generate` —— Ken Burns 拼接（默认，几乎零成本）

3-8 张图片 → 缩放平移动效 → 拼接 → 字幕 → 配乐。已端到端实测跑通，
单条成本几分钱以内。这是目前部署在生产环境、老板实际在用的路径。

### 路径二：`/api/generate-ai` —— 真正的 AI 生成式视频（新增，有真实费用）

单张图片 + 文案 → 调用 Wan 2.6 图生视频模型，真正让画面动起来（冒热气、
光影变化这类真实生成内容，不是简单缩放平移）→ 字幕 → 配乐。

**⚠️ 这条路径没有在开发沙盒里端到端测试过**——开发环境没有访问
AIMLAPI 服务器的网络权限，所以 `src/wanVideo.js` 是严格照着 AIMLAPI
官方文档写的，但没有真实调用验证过。部署后第一件事应该是配好
`WAN_API_KEY` 和 `PUBLIC_BASE_URL`，跑一次 `npm run test:wan`，
确认真的能跑通，再接入前端给老板用。

**⚠️ 这条路径有真实费用**，大概几毛到一两美元一条（取决于用的模型档位
和是否需要重新生成），不是免费的，别在没弄清楚计费规则前大量调用测试。

**用到的环境变量**（在 `.env` 里配置）：
- `WAN_API_KEY` —— 从 AIMLAPI（或其他聚合平台）申请
- `PUBLIC_BASE_URL` —— 你服务器的公网 HTTPS 地址，Wan API 需要通过这个
  URL 抓取你上传的图片，不配置会直接报错拒绝，不会静默失败

**接口字段**（跟 `/api/generate` 不同，注意区分）：
| 字段 | 必填 | 说明 |
|---|---|---|
| `image` | 是 | 只传一张图（字段名单数，不是 `images`） |
| `storeName` | 是 | 店名 |
| `tagline` | 是 | 一句话卖点 |
| `dish` | 否 | 招牌菜，会用来生成运镜提示词 |
| `styleId` | 是 | 决定字幕样式和配乐，不影响生成的动态效果本身 |

**可能需要你自己调整的地方**：
- `src/wanVideo.js` 里的 `duration` 参数目前写死尝试传 `"10"`，但
  AIMLAPI 文档给出的示例用的是 `"5"`，实际支持哪些时长值需要你第一次
  真实调用时验证，如果 10 秒不被接受，改这个值或改成"生成 5 秒 + 循环
  一次拼成 10 秒"这种变通方案
- 创建任务接口返回的任务 ID 字段名，代码里同时兼容了 `id` 和
  `generation_id` 两种可能，第一次测试时如果报"没拿到任务 ID"，去看
  真实返回的 JSON 长什么样，照着调整
- 目前默认用的是 `alibaba/wan-2-6-i2v` 这个 model 字符串，AIMLAPI 上
  还有 `alibaba/wan2.6-i2v-flash`（更快更便宜的版本），想省钱可以换



`multipart/form-data`：

| 字段 | 必填 | 说明 |
|---|---|---|
| `images` | 是 | 3–8 张图片，字段名重复，如 `images` × N |
| `storeName` | 是 | 店名 |
| `tagline` | 是 | 一句话卖点 |
| `dish` | 否 | 招牌菜名称 |
| `styleId` | 是 | `viral` / `festive` / `minimal` / `cozy` |

返回：

```json
{
  "jobId": "...",
  "caption": "生成的字幕文案",
  "videoUrl": "/videos/xxx.mp4"
}
```

失败返回 4xx/5xx + `{ "error": "..." }`。

### `GET /api/styles`

返回可选风格列表（id + 中文名），前端可据此渲染选择卡片，避免前后端定义不同步。

### `GET /health`

健康检查，返回 `{ "ok": true }`。

## 部署说明

**不要部署在 Vercel Serverless Function 上。** FFmpeg 处理一条视频实测耗时
13–18 秒（取决于图片数量和风格），会撞到 serverless 的执行时长限制。

推荐：一台轻量 VPS（1–2 核、2GB 内存足够），用 `pm2` 或 `systemd` 常驻运行，
前面挂 nginx 反代 + HTTPS。前端（Next.js/Vercel）通过 `fetch` 调用这台 VPS
暴露的 API 即可，跨域已经用 `cors` 中间件放开（生产环境建议把 `cors()` 换成
限定具体前端域名的配置，而不是完全放开）。

服务器需要装：`ffmpeg`、Noto CJK 字体（`fonts-noto-cjk`，用于中文字幕渲染）。

```bash
# Ubuntu/Debian 示例
apt install -y ffmpeg fonts-noto-cjk
```

## 已知限制（MVP 阶段，交付前需要处理）

1. **背景音乐是占位音**：沙盒环境无法从外网下载真实授权音乐文件，
   `music.js` 现在用 FFmpeg 合成简单音调撑起流水线跑通。**生产上线前
   必须**把真实的免版权/授权音乐文件放进 `music/{mood}.mp3`
   （`mood` 取值：`upbeat` / `festive` / `calm` / `warm`，对应
   `styles.js` 里每个风格的 `musicMood`），代码会自动优先使用真实文件，
   不需要改其他代码。

2. **无任务队列**：`/api/generate` 是同步处理的，一次处理 13–18 秒。
   并发请求会互相排队甚至压垮单台小 VPS。第一批小规模验证（几家试点
   商户手动使用）没问题，但如果要多商户同时用，需要加一个简单的任务队列
   （比如 `bull` + Redis，或者最简单的内存队列）。

3. **无鉴权、无限流**：接口目前谁都能调用。仅用于内部测试/给试点商户
   演示阶段可以先这样，正式给外部商户使用前需要加一层简单的 API key
   或登录态校验，避免被滥用打满服务器资源。

4. **字幕文案没有人工审核环节**：Claude 生成的文案直接烧录进视频，
   建议生成后先看一遍再发给商户，避免偶发的用词不准确。

5. **图片质量过滤未实现**：目前不检测模糊、过暗、构图问题，商户上传
   什么图就用什么图。之前讨论过的"启发式过滤低质量图片"这块还没做，
   MVP 阶段先靠人工把关传给商户的成片。

## 下一步建议

- 把真实音乐文件放进 `music/`，替换占位音
- 前端 `ClipInOne.jsx` 目前是纯前端原型，还没有接这个 API，需要把"生成"
  按钮的逻辑改成 `FormData` + `fetch(POST /api/generate)`，并轮询/等待
  返回后展示 `videoUrl`
- 找一台 VPS 按上面的部署说明跑起来，用真实商户照片测 2–3 条，人工看
  效果是否达到能发给商户的标准
