/**
 * AI 生成式视频流水线（单图输入）
 *
 * 跟 videoBuilder.js 的 Ken Burns 拼接方案是两条独立的路径：
 * 这条路径真正调用生成式模型让画面"动起来"（比如冒热气、光影变化），
 * 而不是简单地把静态图缩放平移。
 *
 * 流程：单张图片 -> (转为公网可访问 URL) -> 调用 Wan 生成 10 秒动态视频
 *       -> 烧录字幕 -> 混入背景音乐
 */

const fs = require("fs");
const path = require("path");

const { requestAIVideo, downloadVideo } = require("./wanVideo");
const { generateMotionPrompt } = require("./motionPrompt");
const { burnSubtitle, mixMusic } = require("./videoBuilder");
const { ensureMusicFile } = require("./music");

const TARGET_DURATION = 10;

async function buildAIVideo({
  publicImageUrl,
  dish,
  tagline,
  customPrompt,
  style,
  caption,
  outputPath,
  workDir,
}) {
  if (!fs.existsSync(workDir)) fs.mkdirSync(workDir, { recursive: true });

  // 1. 运镜提示词：用户直接给了就用用户的，跳过自动生成；
  //    没给才走 Claude 生成/降级模板那条路
  const motionPrompt = customPrompt?.trim()
    ? customPrompt.trim()
    : await generateMotionPrompt({
        dish,
        tagline,
        styleName: style.name,
      });
  console.log(
    `[aiVideoBuilder] 运镜提示词${customPrompt?.trim() ? "（用户自定义）" : "（自动生成）"}：${motionPrompt}`
  );

  // 2. 调用 Wan 生成动态视频（这一步全靠网络请求，耗时以文档示例约 2-3 分钟为参考）
  const { videoUrl: remoteUrl, creditsUsed } = await requestAIVideo({
    imageUrl: publicImageUrl,
    prompt: motionPrompt,
    duration: String(TARGET_DURATION),
  });
  console.log(
    `[aiVideoBuilder] AI 生成完成，远程地址：${remoteUrl}${
      creditsUsed ? `，消耗 credits：${creditsUsed}` : ""
    }`
  );

  // 3. 下载到本地
  const rawPath = path.join(workDir, "ai_raw.mp4");
  await downloadVideo(remoteUrl, rawPath);

  // 4. 烧录字幕（复用 videoBuilder.js 里已经验证过的逻辑）
  const subbedPath = path.join(workDir, "ai_subbed.mp4");
  await burnSubtitle({
    inputPath: rawPath,
    caption,
    style,
    workDir,
    outputPath: subbedPath,
  });

  // 5. 混入背景音乐
  const musicPath = await ensureMusicFile(style.musicMood);
  await mixMusic({
    videoPath: subbedPath,
    musicPath,
    volume: style.musicVolume,
    duration: TARGET_DURATION,
    outputPath,
  });

  // 清理中间文件
  for (const p of [rawPath, subbedPath]) {
    try {
      fs.unlinkSync(p);
    } catch (_) {}
  }

  return { outputPath, motionPrompt, creditsUsed };
}

module.exports = { buildAIVideo };
