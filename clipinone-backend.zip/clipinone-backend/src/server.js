require("dotenv").config();

const path = require("path");
const fs = require("fs");
const express = require("express");
const cors = require("cors");
const multer = require("multer");
const { v4: uuid } = require("uuid");

const { getStyle, STYLES } = require("./styles");
const { generateCaption } = require("./caption");
const { buildVideo } = require("./videoBuilder");
const { buildAIVideo } = require("./aiVideoBuilder");

const app = express();
const PORT = process.env.PORT || 3001;
// 服务自己的公网地址，用于把上传的图片临时暴露成 Wan API 能抓取的 URL
// 部署时必须在 .env 里配置，例如 https://159-223-175-193.sslip.io
const PUBLIC_BASE_URL = process.env.PUBLIC_BASE_URL || "";

const UPLOAD_DIR = path.join(__dirname, "..", "uploads");
const OUTPUT_DIR = path.join(__dirname, "..", "output");
const TMP_DIR = path.join(__dirname, "..", "tmp");
const SOURCE_IMG_DIR = path.join(__dirname, "..", "source-images");

for (const dir of [UPLOAD_DIR, OUTPUT_DIR, TMP_DIR, SOURCE_IMG_DIR]) {
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
}

app.use(cors());
app.use("/videos", express.static(OUTPUT_DIR));
// 临时公开目录：只用于让 Wan API 能抓到刚上传的图片，生成完成后会清理
app.use("/source-images", express.static(SOURCE_IMG_DIR));

const upload = multer({
  dest: UPLOAD_DIR,
  limits: { fileSize: 25 * 1024 * 1024, files: 8 }, // 单张最大 25MB，最多 8 张
  fileFilter: (req, file, cb) => {
    if (!file.mimetype.startsWith("image/")) {
      return cb(new Error("只支持图片文件"));
    }
    cb(null, true);
  },
});

// 健康检查
app.get("/health", (req, res) => {
  res.json({ ok: true });
});

// 可选风格列表，前端可据此渲染选择卡片，避免前后端风格定义不同步
app.get("/api/styles", (req, res) => {
  const list = Object.entries(STYLES).map(([id, s]) => ({
    id,
    name: s.name,
  }));
  res.json({ styles: list });
});

app.post("/api/generate", upload.array("images", 8), async (req, res) => {
  const jobId = uuid();
  const jobWorkDir = path.join(TMP_DIR, jobId);
  const uploadedFiles = req.files || [];

  try {
    const { storeName, tagline, dish, styleId } = req.body;

    if (!storeName || !tagline) {
      return res.status(400).json({ error: "店名和一句话卖点为必填项" });
    }
    if (uploadedFiles.length < 3) {
      return res.status(400).json({ error: "至少需要上传 3 张图片" });
    }

    let style;
    try {
      style = getStyle(styleId);
    } catch (e) {
      return res.status(400).json({ error: e.message });
    }

    console.log(
      `[job ${jobId}] 开始生成：店铺=${storeName} 风格=${style.name} 图片数=${uploadedFiles.length}`
    );

    // 1. 生成字幕文案
    const caption = await generateCaption({
      storeName,
      tagline,
      dish,
      styleName: style.name,
    });
    console.log(`[job ${jobId}] 字幕文案：${caption}`);

    // 2. 生成视频
    const imagePaths = uploadedFiles.map((f) => f.path);
    const outputPath = path.join(OUTPUT_DIR, `${jobId}.mp4`);

    await buildVideo({
      imagePaths,
      style,
      caption,
      outputPath,
      workDir: jobWorkDir,
    });

    console.log(`[job ${jobId}] 生成完成：${outputPath}`);

    res.json({
      jobId,
      caption,
      videoUrl: `/videos/${jobId}.mp4`,
    });
  } catch (err) {
    console.error(`[job ${jobId}] 失败：`, err.message);
    res.status(500).json({ error: "生成失败，请重试", detail: err.message });
  } finally {
    // 清理上传的原始图片和工作目录
    for (const f of uploadedFiles) {
      fs.unlink(f.path, () => {});
    }
    fs.rm(jobWorkDir, { recursive: true, force: true }, () => {});
  }
});

// AI 生成式视频：单图 + 文案 -> 调用 Wan 生成动态视频（不是 Ken Burns 拼接）
// 成本远高于 /api/generate，按需使用
app.post(
  "/api/generate-ai",
  upload.single("image"),
  async (req, res) => {
    const jobId = uuid();
    const jobWorkDir = path.join(TMP_DIR, jobId);
    const uploadedFile = req.file;
    let publicImagePath = null;

    try {
      if (!PUBLIC_BASE_URL) {
        return res.status(500).json({
          error:
            "服务器未配置 PUBLIC_BASE_URL，无法生成 Wan API 需要的公网图片地址",
        });
      }

      const { storeName, tagline, dish, customPrompt, styleId } = req.body;

      if (!storeName || !tagline) {
        return res.status(400).json({ error: "店名和一句话卖点为必填项" });
      }
      if (!uploadedFile) {
        return res.status(400).json({ error: "请上传一张图片" });
      }

      let style;
      try {
        style = getStyle(styleId);
      } catch (e) {
        return res.status(400).json({ error: e.message });
      }

      console.log(
        `[job ${jobId}] 开始 AI 生成：店铺=${storeName} 风格=${style.name}`
      );

      // 1. 把上传的图片临时复制到公开目录，构造 Wan API 能抓取的 URL
      const ext = path.extname(uploadedFile.originalname) || ".jpg";
      const publicFileName = `${jobId}${ext}`;
      publicImagePath = path.join(SOURCE_IMG_DIR, publicFileName);
      fs.copyFileSync(uploadedFile.path, publicImagePath);
      const publicImageUrl = `${PUBLIC_BASE_URL}/source-images/${publicFileName}`;

      // 2. 生成字幕文案（复用现有逻辑）
      const caption = await generateCaption({
        storeName,
        tagline,
        dish,
        styleName: style.name,
      });
      console.log(`[job ${jobId}] 字幕文案：${caption}`);

      // 3. 调用 Wan 生成动态视频 + 烧字幕 + 配乐
      const outputPath = path.join(OUTPUT_DIR, `${jobId}.mp4`);
      const { motionPrompt, creditsUsed } = await buildAIVideo({
        publicImageUrl,
        dish,
        tagline,
        customPrompt,
        style,
        caption,
        outputPath,
        workDir: jobWorkDir,
      });

      console.log(`[job ${jobId}] AI 生成完成：${outputPath}`);

      res.json({
        jobId,
        caption,
        motionPrompt,
        creditsUsed,
        videoUrl: `/videos/${jobId}.mp4`,
      });
    } catch (err) {
      console.error(`[job ${jobId}] AI 生成失败：`, err.message);
      res
        .status(500)
        .json({ error: "AI 视频生成失败，请重试", detail: err.message });
    } finally {
      if (uploadedFile) fs.unlink(uploadedFile.path, () => {});
      if (publicImagePath) fs.unlink(publicImagePath, () => {});
      fs.rm(jobWorkDir, { recursive: true, force: true }, () => {});
    }
  }
);

app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ error: err.message || "服务器错误" });
});

app.listen(PORT, () => {
  console.log(`ClipInOne 后端服务已启动：http://localhost:${PORT}`);
});
