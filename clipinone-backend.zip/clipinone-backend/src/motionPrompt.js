/**
 * 生成 AI 视频运镜提示词（motion prompt）
 *
 * Wan 等主流视频生成模型的官方示例和文档都是英文提示词，
 * 中文提示词效果不稳定，所以这里统一生成英文描述。
 * 优先用 Claude 根据店铺信息生成贴切的运镜描述；
 * 没配 API key 时降级为一个通用的、适合餐饮场景的固定模板。
 */

const ANTHROPIC_API_URL = "https://api.anthropic.com/v1/messages";
const MODEL = "claude-haiku-4-5-20251001"; // 简单任务用 Haiku 足够，省成本

async function generateMotionPrompt({ dish, tagline, styleName }) {
  const apiKey = process.env.ANTHROPIC_API_KEY;

  if (!apiKey) {
    return fallbackPrompt({ dish });
  }

  const prompt = `You are writing a short motion prompt (English, under 30 words) for an AI
image-to-video model. The input image is a photo from a small local restaurant.
Context: dish "${dish || "food"}", selling point "${tagline || ""}", desired mood "${
    styleName || ""
  }".
Describe subtle, realistic camera motion and ambient movement suited to a
10-second promotional clip (e.g. gentle steam rising, soft camera push-in,
warm light shifting). Output ONLY the prompt text, no quotes, no explanation.`;

  try {
    const res = await fetch(ANTHROPIC_API_URL, {
      method: "POST",
      headers: {
        "content-type": "application/json",
        "x-api-key": apiKey,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: MODEL,
        max_tokens: 80,
        messages: [{ role: "user", content: prompt }],
      }),
    });

    if (!res.ok) {
      console.warn(`[motionPrompt] Claude API 返回 ${res.status}，降级为模板`);
      return fallbackPrompt({ dish });
    }

    const data = await res.json();
    const text = data.content
      ?.filter((b) => b.type === "text")
      .map((b) => b.text)
      .join("")
      .trim();

    return text || fallbackPrompt({ dish });
  } catch (err) {
    console.warn(`[motionPrompt] 调用失败：${err.message}，降级为模板`);
    return fallbackPrompt({ dish });
  }
}

function fallbackPrompt({ dish }) {
  return `Gentle, realistic ambient motion on this ${
    dish || "food"
  } photo: subtle steam rising, soft natural light shifting, slow cinematic camera push-in. Keep the subject and composition unchanged.`;
}

module.exports = { generateMotionPrompt };
