/**
 * Wan 2.6 图生视频 API 客户端
 *
 * 通过 AIMLAPI 这个聚合平台调用，而不是直接对接阿里云官方 DashScope —
 * 官方 API 对海外个人开发者的账号/资质要求更麻烦，聚合平台用信用卡
 * 就能开通，更适合现在的阶段。
 *
 * ⚠️ 重要说明：这段代码是严格按照 AIMLAPI 官方文档写的真实接口调用，
 * 但因为开发沙盒环境没有访问 aimlapi.com 的网络权限，没有被端到端
 * 实测跑通过。部署到你的服务器、配置好真实 API Key 后，第一件事应该
 * 是跑 test-wan.js 做一次真实测试，而不是直接假设它能用。
 *
 * 官方文档参考： https://docs.aimlapi.com/api-references/video-models/alibaba-cloud/wan-2.6-image-to-video
 */

const fs = require("fs");
const path = require("path");
const { execFile } = require("child_process");
const { promisify } = require("util");
const execFileAsync = promisify(execFile);

const API_BASE = "https://api.aimlapi.com/v2";
// 用 Flash（快速/便宜）版本，不是标准版 —— 标准版 alibaba/wan-2-6-i2v
// 实测贵了好几倍，Flash 版本大概 $0.0325/秒，10秒视频约 $0.3，
// 对餐馆宣传视频这种场景完全够用，没必要为用不上的质量多花钱
const MODEL = "alibaba/wan2.6-i2v-flash";

// 轮询设置：文档给出的示例处理耗时约 2 分 52 秒，这里给足够的重试空间
const POLL_INTERVAL_MS = 15000;
const MAX_POLL_ATTEMPTS = 24; // 24 * 15s = 6 分钟超时

/**
 * 提交生成任务并轮询直到完成，返回生成结果的远程视频 URL
 * @param {object} params
 * @param {string} params.imageUrl - 必须是公网可访问的图片 URL（不是本地路径）
 * @param {string} params.prompt - 英文运镜描述
 * @param {string} [params.duration] - 时长（秒），具体支持哪些值以 AIMLAPI 当前文档为准
 */
async function requestAIVideo({ imageUrl, prompt, duration = "5" }) {
  const apiKey = process.env.WAN_API_KEY;
  if (!apiKey) {
    throw new Error(
      "未配置 WAN_API_KEY，无法调用 AI 视频生成。请在 .env 里设置后重启服务。"
    );
  }

  const createRes = await fetch(`${API_BASE}/video/generations`, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${apiKey}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      model: MODEL,
      prompt,
      image_url: imageUrl,
      duration: String(duration),
    }),
  });

  if (!createRes.ok) {
    const text = await createRes.text().catch(() => "");
    throw new Error(
      `Wan 视频生成任务提交失败：HTTP ${createRes.status} ${text.slice(0, 300)}`
    );
  }

  const createData = await createRes.json();
  // 文档里创建接口返回的任务标识字段名在不同版本示例中出现过 id / generation_id，
  // 两个都兼容一下，实测时以真实返回为准，必要时调整这里。
  const generationId = createData.generation_id || createData.id;
  if (!generationId) {
    throw new Error(
      `Wan 任务提交成功但没拿到任务 ID，返回内容：${JSON.stringify(createData).slice(0, 300)}`
    );
  }

  for (let attempt = 0; attempt < MAX_POLL_ATTEMPTS; attempt++) {
    await sleep(POLL_INTERVAL_MS);

    const pollRes = await fetch(
      `${API_BASE}/video/generations?generation_id=${generationId}`,
      {
        headers: { Authorization: `Bearer ${apiKey}` },
      }
    );

    if (!pollRes.ok) {
      console.warn(
        `[wanVideo] 轮询第 ${attempt + 1} 次返回 HTTP ${pollRes.status}，继续重试`
      );
      continue;
    }

    const pollData = await pollRes.json();

    if (pollData.status === "completed" && pollData.video?.url) {
      return {
        videoUrl: pollData.video.url,
        creditsUsed: pollData.meta?.usage?.credits_used,
      };
    }

    if (pollData.status === "failed" || pollData.error) {
      throw new Error(
        `Wan 视频生成失败：${pollData.error?.message || "未知错误"}`
      );
    }
    // 其余情况（queued / processing 等）继续轮询
  }

  throw new Error(
    `Wan 视频生成超时（超过 ${(MAX_POLL_ATTEMPTS * POLL_INTERVAL_MS) / 1000} 秒未完成），请稍后重试`
  );
}

/** 把远程生成结果下载到本地文件 */
async function downloadVideo(remoteUrl, destPath) {
  const res = await fetch(remoteUrl);
  if (!res.ok) {
    throw new Error(`下载生成结果失败：HTTP ${res.status}`);
  }
  const buffer = Buffer.from(await res.arrayBuffer());
  fs.writeFileSync(destPath, buffer);
  return destPath;
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

module.exports = { requestAIVideo, downloadVideo };
