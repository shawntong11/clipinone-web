/**
 * 字幕文案生成
 * 优先调用 Claude API 根据店铺信息生成一句更有吸引力的字幕文案；
 * 如果没有配置 ANTHROPIC_API_KEY，降级为简单模板拼接，保证流水线仍可跑通。
 */

const ANTHROPIC_API_URL = "https://api.anthropic.com/v1/messages";
const MODEL = "claude-sonnet-4-6";

async function generateCaption({ storeName, tagline, dish, styleName }) {
  const apiKey = process.env.ANTHROPIC_API_KEY;

  if (!apiKey) {
    return fallbackCaption({ storeName, tagline, dish });
  }

  const prompt = `你在为一家本地小商户生成短视频字幕文案。要求：
- 只输出字幕本身，不要任何解释或引号
- 中文，不超过14个字
- 语气贴合"${styleName}"这个风格
- 结合以下信息：店名「${storeName}」，卖点「${tagline}」${
    dish ? `，招牌菜「${dish}」` : ""
  }
- 优先突出卖点，不要机械罗列信息`;

  try {
    const res = await fetch(ANTHROPIC_API_URL, {
      method: "POST",
      headers: {
        "content-type": "application/json",
        "x-api-key": apiKey,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: MODEL,
        max_tokens: 60,
        messages: [{ role: "user", content: prompt }],
      }),
    });

    if (!res.ok) {
      console.warn(
        `[caption] Claude API 返回 ${res.status}，降级为模板文案`
      );
      return fallbackCaption({ storeName, tagline, dish });
    }

    const data = await res.json();
    const text = data.content
      ?.filter((b) => b.type === "text")
      .map((b) => b.text)
      .join("")
      .trim();

    if (!text) return fallbackCaption({ storeName, tagline, dish });

    // 保险起见做一次长度截断，避免模型偶尔超出预期长度
    return text.length > 20 ? text.slice(0, 20) : text;
  } catch (err) {
    console.warn(`[caption] 调用 Claude API 失败：${err.message}，降级为模板文案`);
    return fallbackCaption({ storeName, tagline, dish });
  }
}

function fallbackCaption({ storeName, tagline }) {
  // 简单模板：店名 + 卖点，控制在合理长度内
  const combined = `${storeName} · ${tagline}`;
  return combined.length > 20 ? combined.slice(0, 20) : combined;
}

module.exports = { generateCaption };
