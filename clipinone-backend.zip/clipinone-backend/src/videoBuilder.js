/**
 * 核心视频生成流水线
 *
 * 输入：一组图片 + 风格配置 + 字幕文案
 * 输出：一条 10 秒竖屏(9:16) mp4，带字幕、配乐
 *
 * 流程：
 *   1. 每张图片 -> 独立的 Ken Burns 动态片段（zoompan 缩放）
 *   2. 拼接所有片段
 *   3. 烧录字幕（drawtext）
 *   4. 混入背景音乐
 */

const fs = require("fs");
const path = require("path");
const { execFile } = require("child_process");
const { promisify } = require("util");
const execFileAsync = promisify(execFile);

const { ensureMusicFile } = require("./music");

const TARGET_DURATION = 10; // 秒
const WIDTH = 1080;
const HEIGHT = 1920;
const FPS = 30;

async function buildVideo({ imagePaths, style, caption, outputPath, workDir }) {
  if (!imagePaths || imagePaths.length < 3) {
    throw new Error("至少需要 3 张图片");
  }
  if (!fs.existsSync(workDir)) fs.mkdirSync(workDir, { recursive: true });

  const durations = splitDurations(imagePaths.length, TARGET_DURATION);

  // 1. 每张图片生成 Ken Burns 动态片段
  const segmentPaths = [];
  for (let i = 0; i < imagePaths.length; i++) {
    const segPath = path.join(workDir, `seg_${i}.mp4`);
    await buildKenBurnsSegment({
      imagePath: imagePaths[i],
      duration: durations[i],
      style,
      outputPath: segPath,
    });
    segmentPaths.push(segPath);
  }

  // 2. 拼接片段
  const concatPath = path.join(workDir, "concat.mp4");
  await concatSegments(segmentPaths, workDir, concatPath);

  // 3. 烧录字幕
  const subbedPath = path.join(workDir, "subbed.mp4");
  await burnSubtitle({
    inputPath: concatPath,
    caption,
    style,
    workDir,
    outputPath: subbedPath,
  });

  // 4. 混入背景音乐
  const musicPath = await ensureMusicFile(style.musicMood);
  await mixMusic({
    videoPath: subbedPath,
    musicPath,
    volume: style.musicVolume,
    duration: TARGET_DURATION,
    outputPath,
  });

  // 清理中间文件
  cleanup([...segmentPaths, concatPath, subbedPath]);

  return outputPath;
}

/** 把 10 秒平均分给 n 张图片，向下取整到 0.01s 精度，最后一张吸收余数以保证总和精确 */
function splitDurations(n, total) {
  const base = Math.floor((total / n) * 100) / 100;
  const durations = new Array(n).fill(base);
  const usedTotal = base * (n - 1);
  durations[n - 1] = Math.round((total - usedTotal) * 100) / 100;
  return durations;
}

async function buildKenBurnsSegment({ imagePath, duration, style, outputPath }) {
  const frames = Math.max(Math.round(duration * FPS), 1);
  const framesMinus1 = Math.max(frames - 1, 1);
  const zoomTarget = style.zoomTarget;

  // 预放大 1.5 倍再裁切，避免 zoompan 放大后画质变差
  const preW = Math.round(WIDTH * 1.5);
  const preH = Math.round(HEIGHT * 1.5);

  let vf =
    `scale=${preW}:${preH}:force_original_aspect_ratio=increase,` +
    `crop=${preW}:${preH},` +
    `zoompan=z='1+(${zoomTarget}-1)*on/${framesMinus1}':` +
    `d=${frames}:` +
    `x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)':` +
    `s=${WIDTH}x${HEIGHT}:fps=${FPS}`;

  // fade 风格：片段首尾各自淡入淡出，营造柔和过渡感
  if (style.transition === "fade") {
    const td = Math.min(style.transitionDuration, duration / 2);
    vf += `,fade=t=in:st=0:d=${td},fade=t=out:st=${(duration - td).toFixed(
      2
    )}:d=${td}`;
  }

  const args = [
    "-y",
    "-loop",
    "1",
    "-i",
    imagePath,
    "-vf",
    vf,
    "-frames:v",
    String(frames),
    "-r",
    String(FPS),
    "-c:v",
    "libx264",
    "-pix_fmt",
    "yuv420p",
    "-preset",
    "veryfast",
    outputPath,
  ];

  await runFfmpeg(args);
}

async function concatSegments(segmentPaths, workDir, outputPath) {
  const listPath = path.join(workDir, "concat_list.txt");
  const listContent = segmentPaths
    .map((p) => `file '${path.resolve(p)}'`)
    .join("\n");
  fs.writeFileSync(listPath, listContent);

  const args = [
    "-y",
    "-f",
    "concat",
    "-safe",
    "0",
    "-i",
    listPath,
    "-c",
    "copy",
    outputPath,
  ];

  await runFfmpeg(args);
}

async function burnSubtitle({ inputPath, caption, style, workDir, outputPath }) {
  const sub = style.subtitle;

  // 用 textfile 传入文案，避免特殊字符转义问题
  const textFilePath = path.join(workDir, "caption.txt");
  fs.writeFileSync(textFilePath, caption, "utf8");

  const fontColor = hexToFfmpegColor(sub.color);
  const borderColor = hexToFfmpegColor(sub.strokeColor);

  let yExpr;
  if (sub.position === "top") {
    yExpr = `${sub.marginY}`;
  } else if (sub.position === "center") {
    yExpr = `(h-text_h)/2`;
  } else {
    yExpr = `h-text_h-${sub.marginY}`;
  }

  let drawtext =
    `drawtext=fontfile=` +
    resolveFontFile(sub.fontFamily, sub.fontWeight) +
    `:textfile='${textFilePath.replace(/'/g, "'\\''")}':` +
    `fontsize=${sub.fontSize}:fontcolor=${fontColor}:` +
    `borderw=${sub.strokeWidth}:bordercolor=${borderColor}:` +
    `x=(w-text_w)/2:y=${yExpr}`;

  if (sub.boxOpacity > 0) {
    const boxColor = hexToFfmpegColor(sub.boxColor);
    drawtext += `:box=1:boxcolor=${boxColor}@${sub.boxOpacity}:boxborderw=20`;
  }

  const args = [
    "-y",
    "-i",
    inputPath,
    "-vf",
    drawtext,
    "-c:a",
    "copy",
    "-c:v",
    "libx264",
    "-pix_fmt",
    "yuv420p",
    "-preset",
    "veryfast",
    outputPath,
  ];

  await runFfmpeg(args);
}

async function mixMusic({ videoPath, musicPath, volume, duration, outputPath }) {
  const fadeStart = Math.max(duration - 0.6, 0);
  const filter = `[1:a]atrim=0:${duration},afade=t=out:st=${fadeStart}:d=0.6,volume=${volume}[aout]`;

  const args = [
    "-y",
    "-i",
    videoPath,
    "-i",
    musicPath,
    "-filter_complex",
    filter,
    "-map",
    "0:v",
    "-map",
    "[aout]",
    "-c:v",
    "copy",
    "-c:a",
    "aac",
    "-shortest",
    outputPath,
  ];

  await runFfmpeg(args);
}

/** 根据 fontconfig 已注册的字体名找到对应的 ttc/ttf 文件路径，drawtext 用 fontfile 更稳定可靠 */
function resolveFontFile(family) {
  // 沙盒环境验证过的字体路径；实际部署时可根据服务器安装的字体调整或用 fc-match 动态解析
  const map = {
    "Noto Sans CJK SC": "/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc",
    "Noto Serif CJK SC": "/usr/share/fonts/opentype/noto/NotoSerifCJK-Bold.ttc",
  };
  return map[family] || map["Noto Sans CJK SC"];
}

function hexToFfmpegColor(hex) {
  return `0x${hex.replace("#", "")}`;
}

function runFfmpeg(args) {
  return execFileAsync("ffmpeg", args, {
    maxBuffer: 1024 * 1024 * 100,
  }).catch((err) => {
    const stderr = err.stderr || "";
    throw new Error(`FFmpeg 执行失败: ${err.message}\n${stderr.slice(-2000)}`);
  });
}

function cleanup(paths) {
  for (const p of paths) {
    try {
      fs.unlinkSync(p);
    } catch (_) {
      /* 忽略清理失败 */
    }
  }
}

module.exports = { buildVideo, burnSubtitle, mixMusic };
