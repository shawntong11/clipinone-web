/**
 * 背景音乐
 *
 * ⚠️ MVP 占位说明：
 * 沙盒环境无法从外网下载真实的授权音乐文件，这里用 FFmpeg 合成简单的音调
 * 作为占位背景音乐，目的是让整条流水线可以端到端跑通、可测试。
 *
 * 生产部署时，把真实的免版权/授权音乐文件放进 music/ 目录，命名为
 * music/{mood}.mp3（比如 music/upbeat.mp3），代码会自动优先使用真实文件，
 * 不需要改动其他代码。
 */

const path = require("path");
const fs = require("fs");
const { execFile } = require("child_process");
const { promisify } = require("util");
const execFileAsync = promisify(execFile);

const MUSIC_DIR = path.join(__dirname, "..", "music");

// 每种情绪对应一段简单的音符序列（音符, 时值秒），生成占位旋律用
const MOOD_PATTERNS = {
  upbeat: {
    notes: [523, 659, 784, 659, 523, 659, 784, 988], // C5 E5 G5 E5 ...
    noteDuration: 0.22,
    waveform: "sine",
  },
  festive: {
    notes: [659, 784, 988, 784, 659, 523, 659, 784],
    noteDuration: 0.25,
    waveform: "sine",
  },
  calm: {
    notes: [392, 440, 494, 440],
    noteDuration: 0.9,
    waveform: "sine",
  },
  warm: {
    notes: [349, 392, 440, 392, 349, 330],
    noteDuration: 0.55,
    waveform: "sine",
  },
};

async function ensureMusicFile(mood) {
  if (!fs.existsSync(MUSIC_DIR)) fs.mkdirSync(MUSIC_DIR, { recursive: true });

  // 优先使用真实音乐文件（生产环境应放置这些文件）
  const realFile = path.join(MUSIC_DIR, `${mood}.mp3`);
  if (fs.existsSync(realFile)) return realFile;

  // 占位文件已生成过则直接复用，避免每次都重新合成
  const placeholderFile = path.join(MUSIC_DIR, `_placeholder_${mood}.wav`);
  if (fs.existsSync(placeholderFile)) return placeholderFile;

  const pattern = MOOD_PATTERNS[mood] || MOOD_PATTERNS.calm;
  await synthesizePlaceholder(pattern, placeholderFile);
  return placeholderFile;
}

async function synthesizePlaceholder(pattern, outputPath) {
  const { notes, noteDuration, waveform } = pattern;

  // 把音符序列循环到约 14 秒（比 10 秒目标视频略长，供后续裁剪淡出）
  const targetDuration = 14;
  const loopedNotes = [];
  let elapsed = 0;
  let i = 0;
  while (elapsed < targetDuration) {
    loopedNotes.push(notes[i % notes.length]);
    elapsed += noteDuration;
    i += 1;
  }

  // 用 filter_complex 拼接多个 sine 音源，每个加短促的 attack/release 包络
  const inputs = loopedNotes
    .map(
      (freq) =>
        `-f lavfi -i "${waveform}=frequency=${freq}:duration=${noteDuration}"`
    )
    .join(" ");

  const filterParts = loopedNotes
    .map(
      (_, idx) =>
        `[${idx}:a]afade=t=in:st=0:d=0.03,afade=t=out:st=${Math.max(
          noteDuration - 0.05,
          0.01
        )}:d=0.05[a${idx}]`
    )
    .join(";");
  const concatInputs = loopedNotes.map((_, idx) => `[a${idx}]`).join("");
  const filterComplex = `${filterParts};${concatInputs}concat=n=${loopedNotes.length}:v=0:a=1[out]`;

  const cmd = `ffmpeg -y ${inputs} -filter_complex "${filterComplex}" -map "[out]" -ac 2 "${outputPath}"`;

  await execAsync(cmd);
}

function execAsync(cmd) {
  return new Promise((resolve, reject) => {
    execFile("/bin/sh", ["-c", cmd], { maxBuffer: 1024 * 1024 * 50 }, (err, stdout, stderr) => {
      if (err) {
        err.stderr = stderr;
        return reject(err);
      }
      resolve({ stdout, stderr });
    });
  });
}

module.exports = { ensureMusicFile };
