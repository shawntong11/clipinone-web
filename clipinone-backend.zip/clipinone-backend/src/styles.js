/**
 * 风格配置表
 * 每个风格是一组驱动 FFmpeg 处理的参数，不是独立的处理逻辑。
 * 新增风格：在这里加一条配置即可，videoBuilder.js 不需要改动。
 */

const STYLES = {
  viral: {
    name: "网红探店风",
    // 运镜：缩放幅度（1.0 -> targetZoom），幅度越大越有冲击力
    zoomTarget: 1.25,
    // 转场：cut = 硬切，fade = 淡入淡出
    transition: "cut",
    transitionDuration: 0.15,
    // 字幕样式
    subtitle: {
      fontFamily: "Noto Sans CJK SC",
      fontWeight: "Bold",
      fontSize: 64,
      color: "#FFF6F0",
      strokeColor: "#B8351F",
      strokeWidth: 3,
      boxColor: "#D8432A",
      boxOpacity: 0.0, // 走描边而不是底框，更有跳动感
      position: "bottom", // top | center | bottom
      marginY: 220,
    },
    // 背景音乐 mood 标签，用于匹配 music/ 目录下的曲目
    musicMood: "upbeat",
    musicVolume: 0.9,
  },

  festive: {
    name: "节日庆典风",
    zoomTarget: 1.15,
    transition: "cut",
    transitionDuration: 0.1,
    subtitle: {
      fontFamily: "Noto Serif CJK SC",
      fontWeight: "Bold",
      fontSize: 60,
      color: "#E9C87A",
      strokeColor: "#7A2016",
      strokeWidth: 3,
      boxColor: "#000000",
      boxOpacity: 0.0,
      position: "bottom",
      marginY: 200,
    },
    musicMood: "festive",
    musicVolume: 0.85,
  },

  minimal: {
    name: "极简风",
    zoomTarget: 1.08,
    transition: "fade",
    transitionDuration: 0.5,
    subtitle: {
      fontFamily: "Noto Serif CJK SC",
      fontWeight: "Regular",
      fontSize: 48,
      color: "#241F1B",
      strokeColor: "#FFFFFF",
      strokeWidth: 1,
      boxColor: "#FBF6ED",
      boxOpacity: 0.55,
      position: "center",
      marginY: 0,
    },
    musicMood: "calm",
    musicVolume: 0.6,
  },

  cozy: {
    name: "温馨风",
    zoomTarget: 1.12,
    transition: "fade",
    transitionDuration: 0.35,
    subtitle: {
      fontFamily: "Noto Sans CJK SC",
      fontWeight: "Bold",
      fontSize: 56,
      color: "#FFF4E8",
      strokeColor: "#6B3420",
      strokeWidth: 3,
      boxColor: "#000000",
      boxOpacity: 0.0,
      position: "bottom",
      marginY: 210,
    },
    musicMood: "warm",
    musicVolume: 0.75,
  },
};

function getStyle(styleId) {
  const style = STYLES[styleId];
  if (!style) {
    throw new Error(
      `未知风格 "${styleId}"，可选值：${Object.keys(STYLES).join(", ")}`
    );
  }
  return style;
}

module.exports = { STYLES, getStyle };
